[METHOD: rand_2c5c8a20 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRD
add_edge LU
add_edge FR
add_edge FU
[STEP: step_1 | cache_alg=false]
add_edge FD
add_corner BRU
add_edge RU
add_edge BU
[STEP: step_2 | cache_alg=false]
add_edge FL
add_edge LD
add_corner BRD
add_edge BL
[STEP: step_3 | cache_alg=false]
add_corner FLD
add_corner FRU
add_edge BD
add_corner FLU
[STEP: step_4 | cache_alg=false]
add_corner BLD
add_corner BLU
add_edge BR
add_edge RD
[END METHOD]