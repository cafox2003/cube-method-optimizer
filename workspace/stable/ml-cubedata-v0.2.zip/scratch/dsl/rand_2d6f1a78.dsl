[METHOD: rand_2d6f1a78 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FL
add_edge RU
add_edge FR
add_corner FRD
[STEP: step_1 | cache_alg=false]
add_edge FU
add_corner BRU
add_edge BR
add_edge LU
[STEP: step_2 | cache_alg=false]
add_corner BLD
add_corner BRD
add_edge LD
add_corner FLD
[STEP: step_3 | cache_alg=false]
add_edge BU
add_edge RD
add_corner FRU
add_corner FLU
[STEP: step_4 | cache_alg=false]
add_edge FD
add_edge BD
add_corner BLU
add_edge BL
[END METHOD]