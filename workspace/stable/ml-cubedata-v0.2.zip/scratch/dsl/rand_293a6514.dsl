[METHOD: rand_293a6514 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LD
add_corner BRU
add_edge RD
add_edge LU
[STEP: step_1 | cache_alg=false]
add_edge BD
add_edge BU
add_corner FRU
add_edge FR
[STEP: step_2 | cache_alg=false]
add_corner FLU
add_corner FRD
add_edge FL
add_corner BLD
[STEP: step_3 | cache_alg=false]
add_edge FU
add_edge BL
add_corner FLD
add_corner BRD
[STEP: step_4 | cache_alg=false]
add_edge BR
add_edge FD
add_edge RU
add_corner BLU
[END METHOD]