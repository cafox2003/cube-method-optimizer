[METHOD: rand_a47e65f5 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LD
add_edge BR
add_edge RU
add_edge BL
[STEP: step_1 | cache_alg=false]
add_edge FR
add_edge RD
add_corner BLU
add_corner FLD
[STEP: step_2 | cache_alg=false]
add_edge FD
add_corner BRU
add_edge BD
add_edge FU
[STEP: step_3 | cache_alg=false]
add_edge BU
add_corner FRD
add_edge FL
add_corner FRU
[STEP: step_4 | cache_alg=false]
add_corner BLD
add_corner FLU
add_corner BRD
add_edge LU
[END METHOD]