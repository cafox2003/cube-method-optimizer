[METHOD: rand_750a16a1 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRU
add_edge BD
add_edge BU
add_corner BLU
[STEP: step_1 | cache_alg=false]
add_corner BLD
add_edge RU
add_edge LU
add_edge FL
[STEP: step_2 | cache_alg=false]
add_corner FRU
add_corner FLU
add_edge BL
add_edge RD
[STEP: step_3 | cache_alg=false]
add_edge BR
add_corner FLD
add_edge FU
add_corner BRD
[STEP: step_4 | cache_alg=false]
add_edge FR
add_corner FRD
add_edge FD
add_edge LD
[END METHOD]