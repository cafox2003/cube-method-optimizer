[METHOD: rand_f49c2710 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRU
add_edge FD
add_edge BL
add_edge RD
[STEP: step_1 | cache_alg=false]
add_corner FLD
add_corner FRD
add_corner BLD
add_edge BU
[STEP: step_2 | cache_alg=false]
add_edge LD
add_edge FR
add_edge FL
add_edge FU
[STEP: step_3 | cache_alg=false]
add_corner BRD
add_corner BLU
add_edge RU
add_edge LU
[STEP: step_4 | cache_alg=false]
add_edge BD
add_edge BR
add_corner FRU
add_corner FLU
[END METHOD]