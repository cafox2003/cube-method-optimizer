[METHOD: rand_0f182df5 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LD
add_edge BD
add_corner BLD
add_edge FD
[STEP: step_1 | cache_alg=false]
add_edge BU
add_corner FLD
add_corner FLU
add_edge FL
[STEP: step_2 | cache_alg=false]
add_edge FR
add_edge BL
add_corner BLU
add_edge RU
[STEP: step_3 | cache_alg=false]
add_edge RD
add_edge FU
add_corner FRD
add_edge BR
[STEP: step_4 | cache_alg=false]
add_edge LU
add_corner BRD
add_corner BRU
add_corner FRU
[END METHOD]