[METHOD: rand_dfb87211 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BD
add_corner FLU
add_edge LD
add_corner BLU
[STEP: step_1 | cache_alg=false]
add_corner FRU
add_edge BR
add_edge BL
add_edge RU
[STEP: step_2 | cache_alg=false]
add_edge FL
add_edge FR
add_corner FLD
add_corner BRU
[STEP: step_3 | cache_alg=false]
add_corner FRD
add_edge RD
add_edge BU
add_corner BRD
[STEP: step_4 | cache_alg=false]
add_corner BLD
add_edge LU
add_edge FD
add_edge FU
[END METHOD]