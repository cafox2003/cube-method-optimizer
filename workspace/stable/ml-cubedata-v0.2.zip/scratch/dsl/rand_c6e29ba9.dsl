[METHOD: rand_c6e29ba9 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLD
add_corner FRU
add_edge LD
add_edge BU
[STEP: step_1 | cache_alg=false]
add_edge RD
add_edge FU
add_edge FD
add_corner BLD
[STEP: step_2 | cache_alg=false]
add_corner BRD
add_edge RU
add_edge FL
add_corner FLU
[STEP: step_3 | cache_alg=false]
add_edge BL
add_corner FRD
add_edge BD
add_corner BRU
[STEP: step_4 | cache_alg=false]
add_edge BR
add_edge LU
add_corner BLU
add_edge FR
[END METHOD]