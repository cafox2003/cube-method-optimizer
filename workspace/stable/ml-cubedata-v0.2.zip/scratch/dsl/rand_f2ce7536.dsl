[METHOD: rand_f2ce7536 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLD
add_edge RU
add_edge RD
add_corner BRD
[STEP: step_1 | cache_alg=false]
add_edge FL
add_corner FLU
add_edge FU
add_edge FR
[STEP: step_2 | cache_alg=false]
add_edge BR
add_corner FRD
add_corner FLD
add_edge LD
[STEP: step_3 | cache_alg=false]
add_edge FD
add_corner BRU
add_edge LU
add_edge BU
[STEP: step_4 | cache_alg=false]
add_edge BD
add_edge BL
add_corner BLU
add_corner FRU
[END METHOD]