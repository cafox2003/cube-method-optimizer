[METHOD: rand_2a0fca2b | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLD
add_edge BD
add_corner FLD
add_edge FD
[STEP: step_1 | cache_alg=false]
add_edge LU
add_edge BL
add_edge LD
add_corner FRU
[STEP: step_2 | cache_alg=false]
add_edge FU
add_corner BRD
add_corner BLU
add_edge FR
[STEP: step_3 | cache_alg=false]
add_edge BR
add_edge RU
add_corner BRU
add_edge BU
[STEP: step_4 | cache_alg=false]
add_edge RD
add_corner FLU
add_corner FRD
add_edge FL
[END METHOD]