[METHOD: rand_1001a400 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BD
add_edge FD
add_edge FL
add_corner FLU
[STEP: step_1 | cache_alg=false]
add_corner BLD
add_edge BL
add_corner BRD
add_corner FLD
[STEP: step_2 | cache_alg=false]
add_corner FRU
add_corner BLU
add_edge RU
add_edge BR
[STEP: step_3 | cache_alg=false]
add_edge LD
add_edge RD
add_corner FRD
add_edge FR
[STEP: step_4 | cache_alg=false]
add_edge LU
add_edge FU
add_edge BU
add_corner BRU
[END METHOD]