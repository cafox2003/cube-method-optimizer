[METHOD: rand_2bbeb3c7 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FD
add_edge LU
add_edge BR
add_edge BU
[STEP: step_1 | cache_alg=false]
add_corner FLD
add_corner BLU
add_edge FR
add_corner FRU
[STEP: step_2 | cache_alg=false]
add_corner FRD
add_edge FL
add_corner BRU
add_corner FLU
[STEP: step_3 | cache_alg=false]
add_edge FU
add_edge RU
add_corner BRD
add_edge LD
[STEP: step_4 | cache_alg=false]
add_edge BD
add_edge BL
add_corner BLD
add_edge RD
[END METHOD]