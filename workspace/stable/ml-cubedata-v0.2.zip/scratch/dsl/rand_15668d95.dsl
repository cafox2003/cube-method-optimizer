[METHOD: rand_15668d95 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LU
add_edge RU
add_corner FRD
add_edge RD
[STEP: step_1 | cache_alg=false]
add_edge FL
add_corner BLU
add_edge BD
add_corner FLD
[STEP: step_2 | cache_alg=false]
add_corner BRU
add_edge BR
add_edge BU
add_corner FRU
[STEP: step_3 | cache_alg=false]
add_edge FD
add_edge BL
add_corner BRD
add_corner BLD
[STEP: step_4 | cache_alg=false]
add_corner FLU
add_edge LD
add_edge FR
add_edge FU
[END METHOD]