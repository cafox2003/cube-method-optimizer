[METHOD: rand_73b09b84 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLU
add_corner FLU
add_edge LD
add_edge BL
[STEP: step_1 | cache_alg=false]
add_edge BU
add_corner FRU
add_edge FR
add_corner BRU
[STEP: step_2 | cache_alg=false]
add_corner FLD
add_edge RU
add_edge BR
add_edge LU
[STEP: step_3 | cache_alg=false]
add_edge BD
add_edge RD
add_corner BRD
add_edge FL
[STEP: step_4 | cache_alg=false]
add_edge FD
add_edge FU
add_corner BLD
add_corner FRD
[END METHOD]