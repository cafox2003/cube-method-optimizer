[METHOD: rand_b2d151fa | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BR
add_edge FR
add_corner FRD
add_edge FU
[STEP: step_1 | cache_alg=false]
add_edge RU
add_edge LU
add_corner BRD
add_edge BU
[STEP: step_2 | cache_alg=false]
add_edge LD
add_edge RD
add_corner FLD
add_edge FL
[STEP: step_3 | cache_alg=false]
add_corner BLU
add_corner BLD
add_corner FLU
add_edge BL
[STEP: step_4 | cache_alg=false]
add_edge BD
add_corner BRU
add_corner FRU
add_edge FD
[END METHOD]