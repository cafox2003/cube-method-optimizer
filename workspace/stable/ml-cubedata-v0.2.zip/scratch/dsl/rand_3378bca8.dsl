[METHOD: rand_3378bca8 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LU
add_edge RU
add_edge FR
add_corner FRU
[STEP: step_1 | cache_alg=false]
add_edge FD
add_edge BL
add_edge LD
add_corner BRD
[STEP: step_2 | cache_alg=false]
add_corner BLU
add_corner FLU
add_edge BU
add_corner FRD
[STEP: step_3 | cache_alg=false]
add_edge BD
add_edge BR
add_edge FU
add_edge RD
[STEP: step_4 | cache_alg=false]
add_corner BRU
add_edge FL
add_corner FLD
add_corner BLD
[END METHOD]