[METHOD: rand_7b488481 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BR
add_edge BL
add_corner BLD
add_corner BRD
[STEP: step_1 | cache_alg=false]
add_edge LD
add_edge FL
add_edge FR
add_corner FRU
[STEP: step_2 | cache_alg=false]
add_corner FRD
add_edge BD
add_corner BRU
add_edge FD
[STEP: step_3 | cache_alg=false]
add_edge LU
add_edge BU
add_corner FLD
add_edge RD
[STEP: step_4 | cache_alg=false]
add_corner BLU
add_edge FU
add_edge RU
add_corner FLU
[END METHOD]