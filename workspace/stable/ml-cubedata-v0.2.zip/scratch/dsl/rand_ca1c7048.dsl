[METHOD: rand_ca1c7048 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRD
add_edge RD
add_edge FR
add_corner FLD
[STEP: step_1 | cache_alg=false]
add_edge FU
add_corner FLU
add_corner BLD
add_edge RU
[STEP: step_2 | cache_alg=false]
add_edge BU
add_edge BD
add_corner BRD
add_edge BL
[STEP: step_3 | cache_alg=false]
add_edge LD
add_corner FRU
add_edge FL
add_corner BLU
[STEP: step_4 | cache_alg=false]
add_edge LU
add_edge FD
add_edge BR
add_corner BRU
[END METHOD]