[METHOD: rand_b71dee96 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LU
add_edge FR
add_edge FU
add_edge LD
[STEP: step_1 | cache_alg=false]
add_corner FRD
add_edge BL
add_corner FLD
add_edge RD
[STEP: step_2 | cache_alg=false]
add_corner FRU
add_corner BLD
add_edge FL
add_edge RU
[STEP: step_3 | cache_alg=false]
add_corner BRD
add_edge FD
add_edge BR
add_edge BU
[STEP: step_4 | cache_alg=false]
add_corner BRU
add_edge BD
add_corner BLU
add_corner FLU
[END METHOD]