[METHOD: rand_035dc440 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FR
add_edge BD
add_corner BRD
add_edge RD
[STEP: step_1 | cache_alg=false]
add_corner FRU
add_edge FD
add_edge BL
add_edge BR
[STEP: step_2 | cache_alg=false]
add_edge LD
add_corner BLD
add_edge FU
add_corner FLU
[STEP: step_3 | cache_alg=false]
add_corner BLU
add_edge BU
add_edge RU
add_edge FL
[STEP: step_4 | cache_alg=false]
add_corner FLD
add_corner BRU
add_edge LU
add_corner FRD
[END METHOD]