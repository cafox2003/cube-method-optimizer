[METHOD: rand_4761a238 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BD
add_edge RD
add_edge FU
add_edge LD
[STEP: step_1 | cache_alg=false]
add_corner FRU
add_edge FD
add_edge BR
add_corner BLU
[STEP: step_2 | cache_alg=false]
add_edge FL
add_edge FR
add_corner FLU
add_corner BRD
[STEP: step_3 | cache_alg=false]
add_corner FLD
add_edge BL
add_corner FRD
add_edge LU
[STEP: step_4 | cache_alg=false]
add_corner BLD
add_edge BU
add_edge RU
add_corner BRU
[END METHOD]