[METHOD: rand_a11c5bcf | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLD
add_corner BRD
add_edge RU
add_edge FD
[STEP: step_1 | cache_alg=false]
add_edge LD
add_edge BL
add_corner BLD
add_edge RD
[STEP: step_2 | cache_alg=false]
add_corner FRD
add_corner BLU
add_edge LU
add_edge BR
[STEP: step_3 | cache_alg=false]
add_edge BU
add_corner FRU
add_edge FL
add_corner BRU
[STEP: step_4 | cache_alg=false]
add_edge BD
add_edge FU
add_edge FR
add_corner FLU
[END METHOD]