[METHOD: rand_04d0c642 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BD
add_corner FRD
add_edge BL
add_corner FLD
[STEP: step_1 | cache_alg=false]
add_corner FRU
add_corner FLU
add_edge RU
add_corner BLU
[STEP: step_2 | cache_alg=false]
add_edge FU
add_edge FL
add_edge FR
add_edge LU
[STEP: step_3 | cache_alg=false]
add_edge BR
add_corner BRD
add_edge BU
add_corner BRU
[STEP: step_4 | cache_alg=false]
add_edge RD
add_edge FD
add_edge LD
add_corner BLD
[END METHOD]