[METHOD: rand_a04ed355 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BU
add_edge LU
add_corner FLD
add_edge FU
[STEP: step_1 | cache_alg=false]
add_edge RD
add_corner FRD
add_edge FR
add_corner BRU
[STEP: step_2 | cache_alg=false]
add_corner FLU
add_corner BLU
add_edge BL
add_corner FRU
[STEP: step_3 | cache_alg=false]
add_edge LD
add_edge RU
add_corner BRD
add_edge FD
[STEP: step_4 | cache_alg=false]
add_edge BR
add_corner BLD
add_edge FL
add_edge BD
[END METHOD]