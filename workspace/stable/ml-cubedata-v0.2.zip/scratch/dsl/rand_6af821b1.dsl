[METHOD: rand_6af821b1 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRU
add_edge FU
add_corner BLD
add_edge FR
[STEP: step_1 | cache_alg=false]
add_edge BL
add_corner BLU
add_edge RU
add_edge BU
[STEP: step_2 | cache_alg=false]
add_corner FLD
add_corner FLU
add_edge FD
add_edge RD
[STEP: step_3 | cache_alg=false]
add_corner BRD
add_corner BRU
add_edge BD
add_corner FRD
[STEP: step_4 | cache_alg=false]
add_edge LU
add_edge BR
add_edge LD
add_edge FL
[END METHOD]