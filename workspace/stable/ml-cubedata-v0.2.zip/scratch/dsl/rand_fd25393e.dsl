[METHOD: rand_fd25393e | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLD
add_edge RD
add_edge BD
add_edge FL
[STEP: step_1 | cache_alg=false]
add_corner FRD
add_edge LD
add_corner BLD
add_edge FR
[STEP: step_2 | cache_alg=false]
add_corner BLU
add_edge LU
add_edge BR
add_corner BRU
[STEP: step_3 | cache_alg=false]
add_edge FU
add_corner FLU
add_corner BRD
add_edge BL
[STEP: step_4 | cache_alg=false]
add_corner FRU
add_edge RU
add_edge FD
add_edge BU
[END METHOD]