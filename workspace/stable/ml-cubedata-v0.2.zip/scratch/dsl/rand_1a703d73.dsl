[METHOD: rand_1a703d73 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FD
add_edge RU
add_corner BLD
add_edge LU
[STEP: step_1 | cache_alg=false]
add_corner BRD
add_corner FLD
add_edge BD
add_edge FR
[STEP: step_2 | cache_alg=false]
add_edge FL
add_corner BRU
add_corner FRU
add_edge BR
[STEP: step_3 | cache_alg=false]
add_edge BL
add_edge RD
add_edge BU
add_edge FU
[STEP: step_4 | cache_alg=false]
add_corner FLU
add_corner BLU
add_corner FRD
add_edge LD
[END METHOD]