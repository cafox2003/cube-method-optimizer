[METHOD: rand_ace6fd2b | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRU
add_corner FRD
add_edge BU
add_edge FD
[STEP: step_1 | cache_alg=false]
add_edge FL
add_corner BLD
add_edge FU
add_edge BR
[STEP: step_2 | cache_alg=false]
add_edge FR
add_edge BD
add_corner BRD
add_edge RD
[STEP: step_3 | cache_alg=false]
add_corner FLD
add_edge LD
add_corner BRU
add_corner BLU
[STEP: step_4 | cache_alg=false]
add_edge BL
add_corner FLU
add_edge LU
add_edge RU
[END METHOD]