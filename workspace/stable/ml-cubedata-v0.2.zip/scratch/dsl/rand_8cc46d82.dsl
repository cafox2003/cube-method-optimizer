[METHOD: rand_8cc46d82 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLD
add_corner BRU
add_edge RU
add_edge LD
[STEP: step_1 | cache_alg=false]
add_corner BRD
add_corner FRU
add_edge FU
add_edge BR
[STEP: step_2 | cache_alg=false]
add_corner BLU
add_edge FL
add_edge FR
add_corner FRD
[STEP: step_3 | cache_alg=false]
add_edge BD
add_edge BU
add_edge BL
add_edge FD
[STEP: step_4 | cache_alg=false]
add_corner FLD
add_edge RD
add_edge LU
add_corner FLU
[END METHOD]