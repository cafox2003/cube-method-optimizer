[METHOD: rand_8bf86eda | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FR
add_edge FL
add_edge BU
add_edge FD
[STEP: step_1 | cache_alg=false]
add_edge BD
add_edge RU
add_corner FRU
add_corner BLU
[STEP: step_2 | cache_alg=false]
add_edge BL
add_edge LD
add_edge FU
add_corner FRD
[STEP: step_3 | cache_alg=false]
add_edge BR
add_corner BRU
add_corner FLU
add_corner FLD
[STEP: step_4 | cache_alg=false]
add_corner BLD
add_edge RD
add_corner BRD
add_edge LU
[END METHOD]