[METHOD: rand_f973e906 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRU
add_edge FR
add_edge BD
add_corner BLD
[STEP: step_1 | cache_alg=false]
add_corner BLU
add_corner FLU
add_edge RD
add_edge FD
[STEP: step_2 | cache_alg=false]
add_edge BL
add_edge FU
add_corner FRD
add_edge BR
[STEP: step_3 | cache_alg=false]
add_edge BU
add_edge LD
add_edge LU
add_corner BRU
[STEP: step_4 | cache_alg=false]
add_edge FL
add_corner FLD
add_edge RU
add_corner BRD
[END METHOD]