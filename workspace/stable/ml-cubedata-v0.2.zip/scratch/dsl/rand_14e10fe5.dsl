[METHOD: rand_14e10fe5 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge RD
add_edge FR
add_corner BRD
add_edge RU
[STEP: step_1 | cache_alg=false]
add_corner BLD
add_edge LU
add_edge BL
add_corner FLU
[STEP: step_2 | cache_alg=false]
add_edge FU
add_corner FLD
add_edge BD
add_edge LD
[STEP: step_3 | cache_alg=false]
add_edge BR
add_corner FRU
add_edge BU
add_corner FRD
[STEP: step_4 | cache_alg=false]
add_edge FL
add_corner BRU
add_edge FD
add_corner BLU
[END METHOD]