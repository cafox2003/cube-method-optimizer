[METHOD: rand_29c5fd5c | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRU
add_corner BLU
add_edge FU
add_corner BLD
[STEP: step_1 | cache_alg=false]
add_edge BD
add_edge FD
add_edge BU
add_corner BRD
[STEP: step_2 | cache_alg=false]
add_edge FR
add_corner FLU
add_edge FL
add_edge BR
[STEP: step_3 | cache_alg=false]
add_edge RD
add_corner FRU
add_edge LD
add_edge LU
[STEP: step_4 | cache_alg=false]
add_edge RU
add_corner FRD
add_edge BL
add_corner FLD
[END METHOD]