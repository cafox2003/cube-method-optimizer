[METHOD: rand_69de0f04 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LD
add_edge BR
add_edge RD
add_corner FLD
[STEP: step_1 | cache_alg=false]
add_edge RU
add_edge FU
add_corner BRD
add_corner BRU
[STEP: step_2 | cache_alg=false]
add_edge FL
add_edge BL
add_corner FRD
add_corner BLD
[STEP: step_3 | cache_alg=false]
add_corner FLU
add_edge FD
add_corner BLU
add_edge BU
[STEP: step_4 | cache_alg=false]
add_edge BD
add_corner FRU
add_edge FR
add_edge LU
[END METHOD]