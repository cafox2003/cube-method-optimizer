[METHOD: rand_28657641 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRU
add_edge BU
add_corner BLD
add_corner BRD
[STEP: step_1 | cache_alg=false]
add_edge RU
add_corner FRU
add_edge LU
add_corner BLU
[STEP: step_2 | cache_alg=false]
add_edge FU
add_edge FR
add_edge BR
add_corner FRD
[STEP: step_3 | cache_alg=false]
add_edge LD
add_edge FL
add_corner FLD
add_corner FLU
[STEP: step_4 | cache_alg=false]
add_edge BL
add_edge RD
add_edge FD
add_edge BD
[END METHOD]