[METHOD: rand_9b860ea5 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FU
add_edge FL
add_edge RD
add_edge BL
[STEP: step_1 | cache_alg=false]
add_corner BRU
add_edge LU
add_corner BLU
add_corner FRD
[STEP: step_2 | cache_alg=false]
add_edge RU
add_edge FD
add_edge FR
add_corner FLU
[STEP: step_3 | cache_alg=false]
add_edge BR
add_corner BRD
add_corner FLD
add_edge LD
[STEP: step_4 | cache_alg=false]
add_corner FRU
add_edge BU
add_edge BD
add_corner BLD
[END METHOD]