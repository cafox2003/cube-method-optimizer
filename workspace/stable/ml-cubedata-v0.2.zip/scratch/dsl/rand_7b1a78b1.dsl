[METHOD: rand_7b1a78b1 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FU
add_corner BLD
add_edge RD
add_corner BRU
[STEP: step_1 | cache_alg=false]
add_corner FRU
add_edge BL
add_edge BU
add_edge LU
[STEP: step_2 | cache_alg=false]
add_corner FLU
add_corner BLU
add_edge RU
add_edge LD
[STEP: step_3 | cache_alg=false]
add_corner FLD
add_corner BRD
add_corner FRD
add_edge FR
[STEP: step_4 | cache_alg=false]
add_edge BD
add_edge BR
add_edge FL
add_edge FD
[END METHOD]