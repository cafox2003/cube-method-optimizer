[METHOD: rand_d77ec057 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FD
add_corner FRU
add_edge BL
add_corner FLD
[STEP: step_1 | cache_alg=false]
add_edge FR
add_edge LD
add_corner BRD
add_corner FLU
[STEP: step_2 | cache_alg=false]
add_edge RU
add_edge LU
add_corner BRU
add_corner BLU
[STEP: step_3 | cache_alg=false]
add_corner BLD
add_edge FL
add_edge BD
add_edge FU
[STEP: step_4 | cache_alg=false]
add_edge BU
add_edge BR
add_edge RD
add_corner FRD
[END METHOD]