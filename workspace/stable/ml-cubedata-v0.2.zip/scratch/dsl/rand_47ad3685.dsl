[METHOD: rand_47ad3685 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLD
add_corner BRD
add_corner FRD
add_edge BR
[STEP: step_1 | cache_alg=false]
add_edge FL
add_corner BLU
add_edge RU
add_edge LU
[STEP: step_2 | cache_alg=false]
add_edge BL
add_corner FRU
add_edge FU
add_corner BLD
[STEP: step_3 | cache_alg=false]
add_corner FLU
add_edge FR
add_edge RD
add_edge LD
[STEP: step_4 | cache_alg=false]
add_edge FD
add_edge BD
add_edge BU
add_corner BRU
[END METHOD]