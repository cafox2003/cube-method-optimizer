[METHOD: rand_0b45932f | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FR
add_corner BRU
add_edge BR
add_corner BRD
[STEP: step_1 | cache_alg=false]
add_edge FL
add_edge RD
add_edge BL
add_edge LU
[STEP: step_2 | cache_alg=false]
add_corner BLD
add_edge LD
add_edge FU
add_edge BU
[STEP: step_3 | cache_alg=false]
add_edge FD
add_corner BLU
add_edge BD
add_corner FRU
[STEP: step_4 | cache_alg=false]
add_corner FRD
add_corner FLD
add_corner FLU
add_edge RU
[END METHOD]