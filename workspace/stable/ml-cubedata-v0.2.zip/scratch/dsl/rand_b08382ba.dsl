[METHOD: rand_b08382ba | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FU
add_edge RD
add_edge FD
add_edge LD
[STEP: step_1 | cache_alg=false]
add_corner BLU
add_edge BU
add_corner FRU
add_edge BR
[STEP: step_2 | cache_alg=false]
add_edge BL
add_edge FL
add_edge RU
add_corner FLD
[STEP: step_3 | cache_alg=false]
add_corner BLD
add_edge BD
add_edge FR
add_corner FRD
[STEP: step_4 | cache_alg=false]
add_corner FLU
add_edge LU
add_corner BRD
add_corner BRU
[END METHOD]