[METHOD: rand_b11bfc54 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLU
add_corner FLD
add_edge LD
add_corner FRD
[STEP: step_1 | cache_alg=false]
add_edge FU
add_edge LU
add_edge BL
add_corner FLU
[STEP: step_2 | cache_alg=false]
add_corner BLD
add_corner FRU
add_edge RD
add_corner BRD
[STEP: step_3 | cache_alg=false]
add_corner BRU
add_edge BU
add_edge FR
add_edge FL
[STEP: step_4 | cache_alg=false]
add_edge FD
add_edge BR
add_edge RU
add_edge BD
[END METHOD]