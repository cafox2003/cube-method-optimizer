[METHOD: rand_649a177d | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge RD
add_corner FLD
add_edge RU
add_edge FD
[STEP: step_1 | cache_alg=false]
add_corner BRU
add_edge FL
add_edge LD
add_corner BLD
[STEP: step_2 | cache_alg=false]
add_corner BRD
add_edge BR
add_edge BL
add_corner FRU
[STEP: step_3 | cache_alg=false]
add_corner FLU
add_edge BD
add_edge BU
add_corner BLU
[STEP: step_4 | cache_alg=false]
add_edge FR
add_edge FU
add_corner FRD
add_edge LU
[END METHOD]