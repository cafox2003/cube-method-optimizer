[METHOD: rand_f53067f5 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLU
add_edge BD
add_edge FR
add_edge RU
[STEP: step_1 | cache_alg=false]
add_edge FL
add_edge FU
add_corner FRD
add_edge LD
[STEP: step_2 | cache_alg=false]
add_corner BRU
add_corner BLD
add_corner FLD
add_edge RD
[STEP: step_3 | cache_alg=false]
add_edge BL
add_edge LU
add_edge BR
add_edge BU
[STEP: step_4 | cache_alg=false]
add_corner FRU
add_corner FLU
add_corner BRD
add_edge FD
[END METHOD]