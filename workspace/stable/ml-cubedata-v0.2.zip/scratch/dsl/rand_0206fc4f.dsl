[METHOD: rand_0206fc4f | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRU
add_edge FU
add_edge FR
add_edge BR
[STEP: step_1 | cache_alg=false]
add_edge FD
add_corner FRU
add_corner FRD
add_edge RU
[STEP: step_2 | cache_alg=false]
add_edge FL
add_corner BLD
add_corner BRD
add_corner FLD
[STEP: step_3 | cache_alg=false]
add_edge LU
add_edge RD
add_edge LD
add_corner FLU
[STEP: step_4 | cache_alg=false]
add_edge BD
add_edge BU
add_corner BLU
add_edge BL
[END METHOD]