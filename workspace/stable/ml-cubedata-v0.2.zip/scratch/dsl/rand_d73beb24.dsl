[METHOD: rand_d73beb24 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BD
add_edge BR
add_edge BU
add_edge LU
[STEP: step_1 | cache_alg=false]
add_edge FR
add_corner BRU
add_edge FD
add_edge LD
[STEP: step_2 | cache_alg=false]
add_corner FLU
add_corner FLD
add_corner BRD
add_corner BLU
[STEP: step_3 | cache_alg=false]
add_edge RU
add_edge RD
add_edge FU
add_edge FL
[STEP: step_4 | cache_alg=false]
add_edge BL
add_corner BLD
add_corner FRU
add_corner FRD
[END METHOD]