[METHOD: rand_8e5256fd | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LD
add_edge RU
add_edge RD
add_edge FL
[STEP: step_1 | cache_alg=false]
add_corner BRU
add_corner FLU
add_corner FRD
add_edge BD
[STEP: step_2 | cache_alg=false]
add_edge FR
add_corner BLD
add_edge LU
add_edge BR
[STEP: step_3 | cache_alg=false]
add_corner FLD
add_edge BL
add_corner BLU
add_edge FU
[STEP: step_4 | cache_alg=false]
add_edge BU
add_corner FRU
add_edge FD
add_corner BRD
[END METHOD]