[METHOD: rand_02a6a185 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRD
add_edge BU
add_edge BD
add_edge BL
[STEP: step_1 | cache_alg=false]
add_corner BRU
add_edge FD
add_corner FLU
add_edge FR
[STEP: step_2 | cache_alg=false]
add_edge RU
add_corner FLD
add_edge LU
add_edge FU
[STEP: step_3 | cache_alg=false]
add_edge RD
add_corner BLD
add_corner BRD
add_edge BR
[STEP: step_4 | cache_alg=false]
add_edge FL
add_edge LD
add_corner BLU
add_corner FRU
[END METHOD]