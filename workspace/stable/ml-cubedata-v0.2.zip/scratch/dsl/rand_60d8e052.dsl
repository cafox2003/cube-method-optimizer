[METHOD: rand_60d8e052 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FD
add_edge BU
add_edge BD
add_edge RD
[STEP: step_1 | cache_alg=false]
add_edge FR
add_corner FRD
add_edge BL
add_edge BR
[STEP: step_2 | cache_alg=false]
add_corner FLD
add_corner BRU
add_edge LU
add_edge LD
[STEP: step_3 | cache_alg=false]
add_edge RU
add_corner FLU
add_corner BLD
add_edge FU
[STEP: step_4 | cache_alg=false]
add_edge FL
add_corner BLU
add_corner FRU
add_corner BRD
[END METHOD]