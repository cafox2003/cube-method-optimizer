[METHOD: rand_0ec2fa67 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BU
add_corner FRU
add_corner FLU
add_edge BD
[STEP: step_1 | cache_alg=false]
add_corner BRD
add_corner BLU
add_edge FD
add_edge LU
[STEP: step_2 | cache_alg=false]
add_edge LD
add_corner BLD
add_edge FU
add_edge FR
[STEP: step_3 | cache_alg=false]
add_edge RD
add_edge BL
add_edge RU
add_corner FLD
[STEP: step_4 | cache_alg=false]
add_edge BR
add_corner FRD
add_edge FL
add_corner BRU
[END METHOD]