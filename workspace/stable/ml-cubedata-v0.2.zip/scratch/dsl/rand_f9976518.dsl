[METHOD: rand_f9976518 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRU
add_edge RU
add_corner FRD
add_edge FU
[STEP: step_1 | cache_alg=false]
add_edge RD
add_corner BLU
add_edge LU
add_corner BLD
[STEP: step_2 | cache_alg=false]
add_edge FL
add_corner FLU
add_edge BL
add_corner FRU
[STEP: step_3 | cache_alg=false]
add_corner BRD
add_edge LD
add_corner FLD
add_edge BU
[STEP: step_4 | cache_alg=false]
add_edge FD
add_edge BD
add_edge BR
add_edge FR
[END METHOD]